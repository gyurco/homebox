struct io_count {
    int io_read_count;
    int io_write_count;
};

void read_io_count(struct io_count *iocount);

